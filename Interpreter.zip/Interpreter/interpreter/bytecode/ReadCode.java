package interpreter.bytecode;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ReadCode extends ByteCode {
    private String readIn;

    @Override
    public void init(ArrayList<String> byteCode) {}

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        try {
            BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter an integer value: ");
            readIn = buffer.readLine();
            VM.push(Integer.parseInt(readIn));
        } catch (Exception e) {
            System.out.println("Reading integer input error...");
        }
    }

    @Override
    public String toString() {
        return "READ " + readIn;
    }
}
