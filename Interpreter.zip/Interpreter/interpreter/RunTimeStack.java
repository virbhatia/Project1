package interpreter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;

public class RunTimeStack {

    private ArrayList<Integer> RTS;
    private Stack<Integer> framePointer;

    public RunTimeStack() {
        RTS = new ArrayList<>();
        framePointer = new Stack<>();
        // Add initial Frame Pointer
        // main being entry pont leads to frame pointer = 0.
        framePointer.add(0);
    }

    public int maxPop() {

        Iterator iterator = framePointer.iterator();
        int nextFrame = 0, currentFrame = (Integer) iterator.next();
        int sizeFunc = 0;
        if (currentFrame == 0) {
            sizeFunc = 0;
        } else if (iterator.hasNext()) {
            nextFrame = (Integer) iterator.next();
            sizeFunc = currentFrame - nextFrame;
        }
        return sizeFunc;
    }

    public void dump() {

        Iterator iterator = framePointer.iterator();
        int NextFrame, CurrentFrame = (Integer) iterator.next();

        for (int i = 0; i < framePointer.size(); i++) {
            if (iterator.hasNext()) {
                NextFrame = (Integer) iterator.next();
            } else {
                NextFrame = RTS.size();
            }
            if (i >=0) {
                System.out.print("[");
            }
            for (int j = CurrentFrame; j < NextFrame; j++) {
                System.out.print(RTS.get(j));
                if (j != NextFrame - 1) {
                    System.out.print(",");
                }
            }
            if (i >= 0) {
                System.out.print("]");
            }
            CurrentFrame = NextFrame;
        }
        System.out.println("\n");

    }

    public int size() {
        return RTS.size();
    }

    public int peek() {
        return RTS.get(RTS.size()-1);
    }

    public int pop() {

        int popItem = RTS.remove(this.size()-1);
        return popItem;
    }

    public int push(int i) {
        RTS.add(i);
        return this.peek();
    }

    public void newFrameAt(int offset) {
        framePointer.push(RTS.size()-offset);
    }

    public void popFrame() {
        int topVal = this.peek();
        int popVal = framePointer.pop();
        int rtsSize = RTS.size()-1;

        for (int i = rtsSize; i >= popVal; i--) RTS.remove(i);
        RTS.add(topVal);
    }

    public int store(int off) {
        int storeValues = RTS.get(this.size()-1);
        RTS.remove(RTS.size()-1);
        RTS.set(framePointer.peek() + off, storeValues);
        return storeValues;
    }

    public int load(int off) {
        int loadValues = RTS.get(framePointer.peek() + off);
        RTS.add(loadValues);
        return loadValues;
    }

    public Integer push(Integer value) {
        RTS.add(value);
        return this.peek();
    }

}
