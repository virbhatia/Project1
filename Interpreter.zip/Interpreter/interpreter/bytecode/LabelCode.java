package interpreter.bytecode;
import java.util.ArrayList;

public class LabelCode extends ByteCode {
    private String name;

    @Override
    public void init(ArrayList<String> byteCode) {
        // get the label at the index position 0 from the ArrayList
        name = byteCode.get(0);
    }

    @Override
    public void execute(interpreter.VirtualMachine VM) {
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "LABEL " + name;
    }

}
