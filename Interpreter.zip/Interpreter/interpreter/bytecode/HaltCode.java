package interpreter.bytecode;
import java.util.ArrayList;

public class HaltCode extends ByteCode {

    @Override
    public void init(ArrayList<String> byteCode) {}

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        VM.stop();
    }

    @Override
    public String toString() {
        return "HALT";
    }
}
