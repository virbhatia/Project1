package interpreter.bytecode;

import java.util.ArrayList;

public class ReturnCode extends ByteCode {
    private String name;
    private int loc;

    @Override
    public void init(ArrayList<String> byteCode) {
        if (!(byteCode.isEmpty())) {
            name = byteCode.get(0);
        } else {
            name = null;
        }
    }

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        VM.setProgramCounter(VM.popReturnLocation());
        VM.popFrame();
        loc = VM.peek();

    }

    @Override
    public String toString() {
        if (name != null) {
            return "RETURN " + name;
        } else {
            return "RETURN ";
        }
    }
}
