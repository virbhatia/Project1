package interpreter.bytecode;
import java.util.ArrayList;

public class LoadCode extends ByteCode {
    private int Off;
    private String id;


    @Override
    public void init(ArrayList<String> byteCode) {
        Off = Integer.parseInt(byteCode.get(0));
        if (byteCode.size() > 1) {
            id = byteCode.get(1);
        }
    }

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        VM.load(Off);

    }

    @Override
    public String toString() {
        if (id.equals("")) {
            return "LOAD " + Off;
        } else {
            return "LOAD " + Off + " " + id;
        }

    }
}
