package interpreter.bytecode;
import interpreter.VirtualMachine;
import java.util.ArrayList;

public class BopCode extends ByteCode {
    private String OPP;

    @Override
    public void init(ArrayList<String> byteCode) {
        OPP = byteCode.get(0);
    }

    @Override
    public void execute(VirtualMachine VM) {
        int top = VM.pop();
        int second = VM.pop();
        int answer = 0;

        if (OPP.equals("+")) {
            answer = second + top;
        } else if (OPP.equals("-")) {
            answer = second - top;
        } else if (OPP.equals("/")) {
            answer = second / top;
        } else if (OPP.equals("*")) {
            answer = second * top;
        } else if (OPP.equals("==")) {
            if (second == top) {
                answer = 1;
            } else {
                answer = 0;
            }
        } else if (OPP.equals("!=")) {
            if (second == top) {
                answer = 0;
            } else {
                answer = 1;
            }
        } else if (OPP.equals("<=")) {
            if (second <= top) {
                answer = 1;
            } else {
                answer = 0;
            }
        } else if (OPP.equals(">")) {
            if (second > top) {
                answer = 1;
            } else {
                answer = 0;
            }
        } else if (OPP.equals(">=")) {
            if (second >= top) {
                answer = 1;
            } else {
                answer = 0;
            }
        } else if (OPP.equals("<")) {
            if (second < top) {
                answer = 1;
            } else {
                answer = 0;
            }
        } else if (OPP.equals("|")) {
            if (second == 0 && top == 0) {
                answer = 0;
            } else {
                answer = 1;
            }
        } else if (OPP.equals("&")) {
            if (second ==1 && top == 1) {
                answer = 1;
            } else {
                answer = 0;
            }
        }
        VM.push(answer);

    }
    @Override
    public String toString() {
        return "BOP " + OPP;
    }
}
