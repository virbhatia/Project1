package interpreter.bytecode;
import interpreter.VirtualMachine;
import java.util.ArrayList;

public class FalseBranchCode extends BranchCode {
    private int loc;
    private String name;

    @Override
    public void init(ArrayList<String> byteCode) {
        name = byteCode.get(0);
    }

    @Override
    public void execute(VirtualMachine VM) {
        if (VM.pop() == 0) { // if not false execute the next bytecode
            VM.setProgramCounter(loc);
        }
    }

    @Override
    public String getBc() {
        return name;
    }

    @Override
    public int getLoc() {
        return loc;
    }

    @Override
    public void setLoc(int index) {
        loc = index;
    }

    @Override
    public String toString() {
        return "FALSEBRANCH " + name;
    }
}
