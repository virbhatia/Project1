package interpreter.bytecode;
import java.util.ArrayList;

public class StoreCode extends ByteCode {
    private int num;
    private int storeValue;
    private String id;

    @Override
    public void init(ArrayList<String> byteCode) {
        num = Integer.parseInt(byteCode.get(0));
        id = byteCode.get(1);
    }

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        storeValue = VM.peek();
        VM.store(num);
    }

    @Override
    public String toString() {
        return "STORE" + num + " " + id + " " + id + " = " + storeValue;
    }
}
