package interpreter.bytecode;
import interpreter.VirtualMachine;
import java.util.ArrayList;

public class ArgsCode extends ByteCode {
    private int argumentsNum;

    @Override
    public void init(ArrayList<String> byteCode) {
        argumentsNum = Integer.parseInt(byteCode.get(0));

    }

    @Override
    public void execute(VirtualMachine VM) {
        VM.newFrame(argumentsNum);
    }

    @Override
    public String toString() {
        return "ARGS " + argumentsNum;
    }
}
