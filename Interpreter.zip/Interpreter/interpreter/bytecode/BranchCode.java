package interpreter.bytecode;
import java.util.ArrayList;

public abstract class BranchCode extends ByteCode {
    @Override
    public abstract void init(ArrayList<String> byteCode);

    @Override
    public abstract void execute(interpreter.VirtualMachine VM);

    public abstract String getBc();
    public abstract int getLoc();
    public abstract void setLoc(int index);

}
