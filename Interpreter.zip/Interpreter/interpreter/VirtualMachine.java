package interpreter;
import interpreter.bytecode.ByteCode;
import interpreter.bytecode.DumpCode;

import java.util.Stack;

public class VirtualMachine {

    private interpreter.RunTimeStack runStack;
    private Stack returnAddrs;
    private interpreter.Program program;
    private int pc;
    private boolean run;
    private boolean dumpStatus;

    protected VirtualMachine(interpreter.Program program) {
        this.program = program;
    }
    // this function gets bytecode from program and execute related function
    public void executeProgram() {
        pc = 0;
        runStack = new interpreter.RunTimeStack();
        returnAddrs = new Stack<Integer>();
        run = true;
        dumpStatus = true;
        while (run) {
            ByteCode code = program.getCode(pc);
            code.execute(this);

            if (dumpStatus && !(code instanceof DumpCode)) {
                System.out.println(code.toString());
                runStack.dump();
                System.out.println();
            }
            pc++;
        }
    }

    public void stop() {

        run = false;
    }

    public int pop() {
        return runStack.pop();
    }

    public int peek() {
        return runStack.peek();
    }

    public int push(int index) { return runStack.push(index); }

    public int getProgramCounter() {
        return pc;
    }

    public void setProgramCounter(int index) {
        pc = index;
    }

    public int store(int off) {
        return runStack.store(off);
    }

    public int load(int off) {
        return runStack.load(off);
    }

    public void newFrame(int numArgs) {
        runStack.newFrameAt(numArgs);
    }

    public void pushReturnLocation(int i) {
        returnAddrs.push(i);
    }

    public int popReturnLocation() {
        return (Integer)returnAddrs.pop();
    }

    public void popFrame() {
        runStack.popFrame();
    }

    public void setDumpFlag(boolean flag) {
        dumpStatus = flag;
    }

    public int maxPop() {
        return runStack.maxPop();
    }



}
