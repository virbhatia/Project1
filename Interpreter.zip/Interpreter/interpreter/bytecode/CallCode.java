package interpreter.bytecode;
import interpreter.VirtualMachine;
import java.util.ArrayList;

public class CallCode extends BranchCode {
    private int loc;
    private String name;

    @Override
    public void init(ArrayList<String> byteCode) {
        name = byteCode.get(0);

    }

    @Override
    public void execute(VirtualMachine VM) {
        VM.pushReturnLocation(VM.getProgramCounter());
        VM.setProgramCounter(loc);
    }

    @Override
    public String getBc() {
        return name;
    }

    @Override
    public int getLoc() {
        return loc;
    }

    @Override
    public void setLoc(int index) {
        loc = index;
    }

    @Override
    public String toString() {

        return "CALL " + name;
    }
}
