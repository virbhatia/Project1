package interpreter.bytecode;
import java.util.ArrayList;

public class DumpCode extends ByteCode {
    private String name;

    @Override
    public void init(ArrayList<String> byteCode) {
        name = byteCode.get(0);
    }

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        if (name.equals("ON")) {
            VM.setDumpFlag(true);   //
        } else if (name.equals("OFF")) {
            VM.setDumpFlag(false);
        }
    }


    @Override
    public String toString() {
        return "DUMP " + name;
    }

}
