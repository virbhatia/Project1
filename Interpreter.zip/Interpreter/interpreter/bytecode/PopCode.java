package interpreter.bytecode;
import java.util.ArrayList;

public class PopCode extends ByteCode {
    private int popN;

    @Override
    public void init(ArrayList<String> byteCode) {
        popN = Integer.parseInt(byteCode.get(0));
    }

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        int size = VM.maxPop();
        if(size >= popN) {
            size = popN;
        }

        try {
            for (int i=0; i<size; i++) {
                VM.pop();
            }
        } catch (Exception e) {
            System.out.println("Stack over flow error...");
        }
    }

    @Override
    public String toString() {

        return "POP " + popN;
    }
}
