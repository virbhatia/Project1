package interpreter;
import interpreter.bytecode.ByteCode;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class ByteCodeLoader extends Object {
    private BufferedReader byteSource;
    private interpreter.Program prog;

    /**
     * Constructor Simply creates a buffered reader.
     * YOU ARE NOT ALLOWED TO READ FILE CONTENTS HERE
     * THIS NEEDS TO HAPPEN IN LOADCODES.
     */
    public ByteCodeLoader(String file) throws IOException {
        this.byteSource = new BufferedReader(new FileReader(file));
        this.prog = new interpreter.Program();
    }
    /**
     * This function should read one line of source code at a time.
     * For each line it should:
     *      Tokenize string to break it into parts.
     *      Grab THE correct class name for the given ByteCode from CodeTable
     *      Create an instance of the ByteCode class name returned from code table.
     *      Parse any additional arguments for the given ByteCode and send them to
     *      the newly created ByteCode instance via the init function.
     */
    public interpreter.Program loadCodes() {
        String next;
        String keyCode;
        String ClassCode;
        ByteCode byteCode;
        ArrayList<String> loadBC = new ArrayList<>();

        try {
            next = byteSource.readLine();

            while (next != null) {
                StringTokenizer strTokenizer = new StringTokenizer(next);
                keyCode = strTokenizer.nextToken(); // returns the next token from this string tokenizer
                ClassCode = interpreter.CodeTable.getClassName(keyCode);

                // this builds the class related to bytecode
                byteCode = (ByteCode)(Class.forName("interpreter.bytecode." + ClassCode).newInstance());

                while (strTokenizer.hasMoreTokens()) {
                    loadBC.add(strTokenizer.nextToken());
                }

                byteCode.init(loadBC);

                //store the bytocode instance
                prog.addByteCode(byteCode); // delegate addByteCode to the Program class

                loadBC.clear();
                //read nextline
                next= byteSource.readLine();
            }
        } catch (Exception e) {
            System.out.println("Error loading ByteCodes...");
            System.out.println(e);
        }


        /*
         * At this stage all bytecodes are loaded to program, so NEXT
         * resolve all symbolic address [def: page_9.05]
         * IMPORTANT: address resolution should not modify the original source code,
         * all source changes are made to the Program object
         */
        try {
            // address resolution to the Program class
            prog.resolveAddrs(prog);
        } catch (Exception e) {
            System.out.println("ByteCodLoader resolve address error...");
        }

        return prog;
    }
}
