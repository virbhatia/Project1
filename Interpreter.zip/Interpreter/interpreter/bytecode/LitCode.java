package interpreter.bytecode;
import java.util.ArrayList;

public class LitCode extends ByteCode {
    private int num;
    private String val = "";

    @Override
    public void init(ArrayList<String> byteCode) {
        num = Integer.parseInt(byteCode.get(0));
        if (byteCode.size() > 1) {
            val = byteCode.get(1);
        }
    }

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        if (val.equals("")) {
            VM.push(num);
        } else {
            VM.push(0);
        }
    }

    @Override
    public String toString() {
        if (val.equals("")) {
            return "LIT " + num;
        } else {
            return "LIT " + num + " " + val;
        }
    }
}
