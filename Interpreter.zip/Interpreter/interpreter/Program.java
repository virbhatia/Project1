package interpreter;
import interpreter.bytecode.BranchCode;
import interpreter.bytecode.ByteCode;
import interpreter.bytecode.LabelCode;

import java.util.ArrayList;
import java.util.HashMap;

public class Program {

    private ArrayList<ByteCode> prog;
    private HashMap<String, Integer> myMap;

    public Program() {
        prog = new ArrayList<>();
        myMap = new HashMap<>();
    }

    protected ByteCode getCode(int pc) {
        return this.prog.get(pc);
    }

    public int getSize() {
        return this.prog.size();
    }

    /**
     * This function should go through the program and resolve all addresses.
     * Currently all labels look like LABEL <<num>>>, these need to be converted into
     * correct addresses so the VirtualMachine knows what to set the Program Counter(PC)
     * HINT: make note what type of data-stucture bytecodes are stored in.
     *
     * @param program Program object that holds a list of ByteCodes
     */
    // this stores the line of code in the hashmap
    public void addByteCode(ByteCode byteCode) {
        // check for bytecode and LabelCode type
        if (byteCode instanceof LabelCode) {
            LabelCode label = (LabelCode)byteCode;
            myMap.put(label.getName(), prog.size());
        }
        prog.add(byteCode);
    }

    public void resolveAddrs(Program program) {
        int jump_Addrs;

        for (int i = 0; i < program.getSize(); i++) {
            if (program.getCode(i) instanceof BranchCode) {
                BranchCode branch = (BranchCode) program.getCode(i);
                //this gets the matching address
                jump_Addrs = myMap.get(branch.getBc());
                branch.setLoc(jump_Addrs);
            }
        }
    }

}
