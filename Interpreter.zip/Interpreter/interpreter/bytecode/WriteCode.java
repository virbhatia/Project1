package interpreter.bytecode;
import java.util.ArrayList;

public class WriteCode extends ByteCode {

    @Override
    public void init(ArrayList<String> byteCode) {}

    @Override
    public void execute(interpreter.VirtualMachine VM) {
        System.out.println(VM.peek()); // display but do not remove the value
    }

    @Override
    public String toString() {
        return "WRITE";
    }
}
